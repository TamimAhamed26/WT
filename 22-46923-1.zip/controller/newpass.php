

<html>
    <center>
    <head>
        <title>banking app</title>
    </head>
    

    <body>
    <h1>ABC BANGKING</h1>
    <h2>Ceate New Password</h2>
    
    <form method="POST" action="../controller/newpasscheck.php" novalidate>
     
     
    <table>
             <br>
             <tr>
                <th><label for="PASS">New Pass</label></th>
                <td>:</td>
                <td>
                <input type="password" id="PASS" name="Pass" >
                </td>
            </tr>
       
       </table>

       <input type="submit" value="Set Password" >
    </form>


    <br>
    <footer>powered by @abc bank</footer>
</body>
</center>
    </html>

















